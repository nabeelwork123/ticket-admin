 <!-- Apple Touch Icon -->
 <!-- <link rel="apple-touch-icon" sizes="180x180" href="/img/apple-touch-icon.png"> -->

<!-- Favicon -->
<link rel="icon"  href="assets/img/favicon.png">

<!-- Theme Script js -->
<script src="assets/js/theme-script.js" type="text/javascript"></script>

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">


<!-- Fancybox CSS -->
<link rel="stylesheet" href="assets/css/jquery.fancybox.min.css">

<!-- Feather CSS -->
<link rel="stylesheet" href="assets/css/feather.css">

<!-- Tabler Icon CSS -->
<link rel="stylesheet" href="assets/css/bootstrap-icons.min.css">

<!-- Tabler Icon CSS -->
<link rel="stylesheet" href="assets/css/tabler-icons.css">


<!-- Select2 CSS -->
<link rel="stylesheet" href="assets/css/select2.min.css">


<!-- Fontawesome CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"  />
<!-- <link rel="stylesheet" href="assets/css/fontawesome.min.css"> -->
<link rel="stylesheet" href="assets/css/all.min.css">

 <!-- Color Picker Css -->
<link rel="stylesheet" href="assets/css/flatpickr.min.css">
<link rel="stylesheet" href="assets/css/nano.min.css">

<!-- Daterangepikcer CSS -->
<link rel="stylesheet" href="assets/css/daterangepicker.css">

<!-- Owl carousel CSS -->
<link rel="stylesheet" href="assets/css/owl.carousel.min.css">

<!-- Datatable CSS -->
<link rel="stylesheet" href="assets/css/dataTables.bootstrap5.min.css">

<!-- Player CSS -->
<link rel="stylesheet" href="assets/css/plyr.css">

<!-- Owl Carousel -->
<link rel="stylesheet" href="assets/css/owl.carousel.min.css">

<!-- Summernote CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.9.1/summernote.min.css"  />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.9.1/summernote-lite.min.css"  />
<!-- <link rel="stylesheet" href="assets/css/summernote-lite.min.css"> -->

<!-- Datetimepicker CSS -->
<link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css">

<!-- Select2 CSS -->
<link rel="stylesheet" href="assets/css/select2.min.css">

<!-- Dragula CSS -->
<link rel="stylesheet" href="assets/css/dragula.min.css">

<!-- ChartC3 CSS -->
<link rel="stylesheet" href="assets/css/c3.min.css">

<!-- Bootstrap Tagsinput CSS -->
<link rel="stylesheet" href="assets/css/bootstrap-tagsinput.css">

<!-- Rangeslider CSS -->
<link rel="stylesheet" href="assets/css/ion.rangeSlider.min.css">


<!-- Morris CSS -->
<link rel="stylesheet" href="assets/css/morris.css">

<!-- Material CSS -->
<link rel="stylesheet" href="assets/css/materialdesignicons.css">

<!-- Pe7 CSS -->
<link rel="stylesheet" href="assets/css/pe-icon-7.css">



<link rel="stylesheet" href="assets/css/flatpickr.css" />
<link rel="stylesheet" href="assets/css/bootstrap-datepicker.css" />
<link rel="stylesheet" href="assets/css/jquery-timepicker.css" />
<link rel="stylesheet" href="assets/css/pickr-themes.css" />


<!-- Pe7 CSS -->
<link rel="stylesheet" href="assets/css/typicons.css">

<!-- Pe7 CSS -->
<link rel="stylesheet" href="assets/css/flags.css">

<!-- Pe7 CSS -->
<link rel="stylesheet" href="assets/css/weathericons.css">


<!-- Custom CSS -->
<link rel="stylesheet" href="assets/css/custom.css">


<!-- Main CSS -->
<link rel="stylesheet" href="assets/css/style.css">
